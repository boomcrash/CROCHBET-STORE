import { Component } from '@angular/core';

@Component({
  selector: 'app-editar-resenia',
  templateUrl: './editar-resenia.component.html',
  styleUrls: ['./editar-resenia.component.css']
})
export class EditarReseniaComponent {

}
