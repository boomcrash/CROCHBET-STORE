import { Component } from '@angular/core';

@Component({
  selector: 'app-insertar-resenia',
  templateUrl: './insertar-resenia.component.html',
  styleUrls: ['./insertar-resenia.component.css']
})
export class InsertarReseniaComponent {

}
