import { Component } from '@angular/core';

@Component({
  selector: 'app-eliminar-resenia',
  templateUrl: './eliminar-resenia.component.html',
  styleUrls: ['./eliminar-resenia.component.css']
})
export class EliminarReseniaComponent {

}
