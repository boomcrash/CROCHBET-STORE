import { Component } from '@angular/core';

@Component({
  selector: 'app-listar-resenia',
  templateUrl: './listar-resenia.component.html',
  styleUrls: ['./listar-resenia.component.css']
})
export class ListarReseniaComponent {

}
