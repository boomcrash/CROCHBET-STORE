import { Component } from '@angular/core';

@Component({
  selector: 'app-insertar-proveedor',
  templateUrl: './insertar-proveedor.component.html',
  styleUrls: ['./insertar-proveedor.component.css']
})
export class InsertarProveedorComponent {

}
